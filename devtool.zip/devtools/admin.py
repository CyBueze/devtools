from django.contrib import admin
from .models import DevTool
# Register your models here

admin.site.register(DevTool)
